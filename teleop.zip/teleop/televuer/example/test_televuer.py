import os, sys
this_file = os.path.abspath(__file__)
project_root = os.path.abspath(os.path.join(os.path.dirname(this_file), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import time
from televuer import TeleVuer
import logging_mp
logger_mp = logging_mp.getLogger(__name__)
logger_mp.setLevel(logging_mp.INFO)

def run_test_TeleVuer():
    use_hand_track = False
    # teleimager, if you want to test real image streaming, make sure teleimager server is running
    from teleimager.image_client import ImageClient
    img_client = ImageClient(host="10.170.3.178") #ImageClient(host="192.168.123.164")
    camera_config = img_client.get_cam_config()
    # teleimager + televuer
    tv = TeleVuer(use_hand_tracking=False, 
                  binocular=camera_config['head_camera']['binocular'],
                  img_shape=camera_config['head_camera']['image_shape'],
                  display_fps=camera_config['head_camera']['fps'],
                  display_mode="immersive",   # "ego" or "immersive" or "pass-through"
                  zmq=camera_config['head_camera']['enable_zmq'],
                  webrtc=camera_config['head_camera']['enable_webrtc'],
                  webrtc_url=f"https://10.170.3.178:{camera_config['head_camera']['webrtc_port']}/offer"
                  )
    # pure televuer
    # tv = TeleVuer(use_hand_tracking=use_hand_track, 
    #               binocular=True, 
    #               img_shape=(480, 1280), 
    #               display_fps=30.0,
    #               display_mode="ego",      # "ego" or "immersive" or "pass-through"
    #               zmq=False,
    #               webrtc=True, 
    #               webrtc_url="https://192.168.123.164:60001/offer"
    #               )

    try:
        input("Press Enter to start TeleVuer test...")
        running = True
        while running:
            #img, _= img_client.get_head_frame()
            #tv.render_to_xr(img)
            start_time = time.time()
            #logger_mp.info("=" * 80)
            #logger_mp.info("Common Data (always available):")
            #logger_mp.info(f"head_pose shape: {tv.head_pose.shape}\n{tv.head_pose}\n")
            #logger_mp.info(f"left_arm_pose shape: {tv.left_arm_pose.shape}\n{tv.left_arm_pose}\n")
            #logger_mp.info(f"right_arm_pose shape: {tv.right_arm_pose.shape}\n{tv.right_arm_pose}\n")
            #logger_mp.info("=" * 80)

            if use_hand_track:
                logger_mp.info("Hand Tracking Data:")
                logger_mp.info(f"left_hand_positions shape: {tv.left_hand_positions.shape}\n{tv.left_hand_positions}\n")
                logger_mp.info(f"right_hand_positions shape: {tv.right_hand_positions.shape}\n{tv.right_hand_positions}\n")
                logger_mp.info(f"left_hand_orientations shape: {tv.left_hand_orientations.shape}\n{tv.left_hand_orientations}\n")
                logger_mp.info(f"right_hand_orientations shape: {tv.right_hand_orientations.shape}\n{tv.right_hand_orientations}\n")
                logger_mp.info(f"left_hand_pinch: {tv.left_hand_pinch}")
                logger_mp.info(f"left_hand_pinchValue: {tv.left_hand_pinchValue}")
                logger_mp.info(f"left_hand_squeeze: {tv.left_hand_squeeze}")
                logger_mp.info(f"left_hand_squeezeValue: {tv.left_hand_squeezeValue}")
                logger_mp.info(f"right_hand_pinch: {tv.right_hand_pinch}")
                logger_mp.info(f"right_hand_pinchValue: {tv.right_hand_pinchValue}")
                logger_mp.info(f"right_hand_squeeze: {tv.right_hand_squeeze}")
                logger_mp.info(f"right_hand_squeezeValue: {tv.right_hand_squeezeValue}")
            else:
              # 1. Capture all raw values
                lct = tv.left_ctrl_trigger
                lctv = tv.left_ctrl_triggerValue
                lcs = tv.left_ctrl_squeeze
                lcsv = tv.left_ctrl_squeezeValue
                lcth = tv.left_ctrl_thumbstick
                lcthv = tv.left_ctrl_thumbstickValue
                lca = tv.left_ctrl_aButton
                lcb = tv.left_ctrl_bButton
                
                rct = tv.right_ctrl_trigger
                rctv = tv.right_ctrl_triggerValue
                rcs = tv.right_ctrl_squeeze
                rcsv = tv.right_ctrl_squeezeValue
                rctth = tv.right_ctrl_thumbstick
                rctthv = tv.right_ctrl_thumbstickValue
                rca = tv.right_ctrl_aButton
                rcb = tv.right_ctrl_bButton

                # 2. Define "Triggered" logic with a small deadzone (0.01) to ignore jitter
                # We use abs() for thumbsticks to catch movement in any direction
                triggered = (
                    lctv > 0.01 or lcsv > 0.01 or 
                    abs(lcthv[0]) > 0.01 or abs(lcthv[1]) > 0.01 or
                    lca or lcb or
                    rctv > 0.01 or rcsv > 0.01 or 
                    abs(rctthv[0]) > 0.01 or abs(rctthv[1]) > 0.01 or
                    rca or rcb
                )

                # 3. Print everything ONLY if triggered
                if triggered:
                    logger_mp.info(">>> CONTROLLER TRIGGERED <<<")
                    logger_mp.info(f"L_Trig: {lct} ({lctv:.2f}) | R_Trig: {rct} ({rctv:.2f})")
                    logger_mp.info(f"L_Sqz:  {lcs} ({lcsv:.2f}) | R_Sqz:  {rcs} ({rcsv:.2f})")
                    logger_mp.info(f"L_Stick: {lcth} {lcthv} | R_Stick: {rctth} {rctthv}")
                    logger_mp.info(f"L_Btns: A={lca} B={lcb} | R_Btns: A={rca} B={rcb}")
                    logger_mp.info("=" * 60)

            current_time = time.time()
            time_elapsed = current_time - start_time
            sleep_time = max(0, 0.016 - time_elapsed)
            time.sleep(sleep_time)
            logger_mp.debug(f"main process sleep: {sleep_time}")
    except KeyboardInterrupt:
        running = False
        logger_mp.warning("KeyboardInterrupt, exiting program...")
    finally:
        tv.close()
        logger_mp.warning("Finally, exiting program...")
        exit(0)

if __name__ == '__main__':
    run_test_TeleVuer()
