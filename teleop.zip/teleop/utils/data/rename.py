import os
import re

# Update this to the path where your episode folders are located
folder_path = "./new" 
start_index = 184

# Find all folders matching the pattern "episode_XXXX"
folders = [f for f in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, f)) and f.startswith("episode_")]

# Sort them numerically based on the digits in the name
# This ensures episode_10 comes after episode_2, instead of alphabetical sorting
folders.sort(key=lambda f: int(re.search(r'\d+', f).group()))

print(f"Found {len(folders)} folders to rename.")

# Rename them in reverse order to prevent overwriting conflicts
for i, folder_name in enumerate(reversed(folders)):
    # Calculate the new index based on the end of the list
    current_index = start_index + len(folders) - 1 - i
    new_name = f"episode_{current_index:04d}"
    
    old_dir = os.path.join(folder_path, folder_name)
    new_dir = os.path.join(folder_path, new_name)
    
    os.rename(old_dir, new_dir)
    print(f"Renamed: {folder_name} -> {new_name}")

print("Batch renaming complete!")