from vuer import Vuer

def test_vuer():
    vuer = Vuer()
    assert vuer is not None

