import zmq
import cv2
import numpy as np

context = zmq.Context()
socket = context.socket(zmq.SUB)
socket.connect("tcp://192.168.123.161:55555") # Use your robot IP
socket.setsockopt_string(zmq.SUBSCRIBE, "")

print("Waiting for frames...")
while True:
    print("In loop...")
    message = socket.recv()
    print("Not reach here")
    # If the robot is sending raw BGR buffers
    image = np.frombuffer(message, dtype=np.uint8).reshape(480, 640, 3)
    cv2.imshow("G1 Head Cam Test", image)
    if cv2.waitKey(1) == ord('q'): break
